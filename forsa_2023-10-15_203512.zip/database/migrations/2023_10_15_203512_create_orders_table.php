<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrdersTable extends Migration {

	public function up()
	{
		Schema::create('orders', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('client_id')->unsigned();
			$table->float('cost');
			$table->float('delivary_cost');
			$table->float('total_cost');
			$table->integer('payment_type_id')->unsigned();
			$table->enum('status', array('pending', 'accepted', 'rejected', 'delivered'));
			$table->string('address');
			$table->integer('restaurant_id')->unsigned();
			$table->float('commission');
		});
	}

	public function down()
	{
		Schema::drop('orders');
	}
}