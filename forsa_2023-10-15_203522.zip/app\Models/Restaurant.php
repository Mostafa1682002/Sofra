<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model 
{

    protected $table = 'restaurants';
    public $timestamps = true;
    protected $fillable = array('name', 'email', 'password', 'phone', 'regoin_id', 'minimum_order', 'delivary_cost', 'whatsapp', 'image', 'status', 'remember_me', 'api_token', 'code');
    protected $hidden = array('password', 'remember_me', 'api_token', 'code');

    public function products()
    {
        return $this->hasMany('App\Models\Product');
    }

    public function offers()
    {
        return $this->hasMany('App\Models\Offer');
    }

    public function regoin()
    {
        return $this->belongsTo('App\Models\Regoin');
    }

    public function orders()
    {
        return $this->hasMany('App\Models\Order');
    }

    public function notifications()
    {
        return $this->morphMany('App\Models\Offer', 'notificationable');
    }

    public function token()
    {
        return $this->morphOne('App\Models\Token', 'tokenable');
    }

    public function transactions()
    {
        return $this->hasMany('App\Models\Transaction');
    }

    public function categories()
    {
        return $this->belongsToMany('App\Models\Category');
    }

    public function clients()
    {
        return $this->belongsToMany('App\Models\Client')->withPivot('rate','comment');
    }

}